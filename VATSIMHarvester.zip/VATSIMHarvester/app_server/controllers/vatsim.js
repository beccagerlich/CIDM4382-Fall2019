const request = require('request');
const selected_Port = process.env.PORT || '3000'; //line 16
const apiOptions = {
  server: 'http://localhost:' + selected_Port //steel from 
};

const Airports = [
    //Class Bravo Airports
    "KMIA", 
    "KTPA",
    //Class Charlie Airports
    "KFLL",
    "KPBI",
    "KRSW",
    "KSRQ",
    //Class Delta Airports
    "06FA",
    "KBCT",
    "KBKV", 
    "KBOW", 
    "KEYW", 
    "KFMY", 
    "KFPR",       
    "KFXE", 
    "KHST", 
    "KHWO",                  
    "KLAL", 
    "KMCF", 
    "KOPE", 
    "KNQX", 
    "KPGD", 
    "KPIE", 
    "KPMP", 
    "KSPG", 
    "KSUA", 
    "KTMB", 
    "KVRB" 
  ];

// Airports.forEach((airport) => {
//     console.log(airport);
// })

let selectedAirport = "KMIA";

const vatsimAirportSelection = (req, res) => {
    console.log(req.body);
    selectedAirport = req.body.selectedAirport;//make sure there is a value
    console.log(`Selected Airport: ${selectedAirport}`);
    vatsimArrivals(req, res);
}

const vatsimArrivals = (req, res) => {
    // /arrived/:airport/:howMany/:offset
    console.log(`Selected Airport: ${selectedAirport}`);
    const path = `/api/arrived/${selectedAirport}/15/0`;
    const requestOptions = {
      url: `${apiOptions.server}${path}`,
      method: 'GET',
      json: {},
    };
    request(
      requestOptions,
      (err, {statusCode}, body) => {
        let data = [];
        if (statusCode === 200 && body.length) { //if !err && the rest of the code. this would check for errors
            data = body;
        }
        renderArrivalsPage(req, res, data);
      }
    );
};
  
const renderArrivalsPage = (req, res, responseBody) => { //pug page
    let message = null;
    if (!(responseBody instanceof Array)) { //is this an array? if not then do code
      message = 'API lookup error';
      responseBody = [];
    } else {
      if (!responseBody.length) {
        message = 'No results for this airport'; //if it has no length then no results
      }
    }
    res.render('arrivals', //should render err
        { //what you want to use
            airports: Airports,
            clients: responseBody, //in pug call clients
            message, //lable and value are the same
            selectedAirport
        }
    );
};

  module.exports = {
    vatsimArrivals,
    vatsimAirportSelection
  };